﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP_FUNDA_GRUPO1
{
    public partial class FormRegistroPedido : Form
    {
        public FormRegistroPedido()
        {
            InitializeComponent();
        }

        private void btnSeleccionar_Click(object sender, EventArgs e)
        {
            this.Hide();

            FormSolicitudPedido form = new FormSolicitudPedido();

            form.Show();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Hide();

            FormPrincipal form = new FormPrincipal();

            form.Show();
        }

        private void btnPerfil_Click(object sender, EventArgs e)
        {
            this.Hide();

            FormModificarPerfil form = new FormModificarPerfil();

            form.Show();
        }
    }
}
