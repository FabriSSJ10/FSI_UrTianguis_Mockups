﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP_FUNDA_GRUPO1
{
    public partial class FormSolicitudPedido : Form
    {
        public FormSolicitudPedido()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRegistroPedido form = new FormRegistroPedido();
            form.Show();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormPago form = new FormPago();
            form.Show();
        }
    }
}
