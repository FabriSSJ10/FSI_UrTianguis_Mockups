﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP_FUNDA_GRUPO1
{
    public partial class FormMenuAdministrativo : Form
    {
        public FormMenuAdministrativo()
        {
            InitializeComponent();
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormPrincipal form = new FormPrincipal();
            form.Show();
        }

        private void btnRegistroUsuario_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRegistroUsuarioAdmin form = new FormRegistroUsuarioAdmin();
            form.Show();
        }

        private void btnRegistroPrenda_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRegistroPrenda form = new FormRegistroPrenda();
            form.Show();
        }

        private void btnRegistroPedido_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRegistroPedidoAdmin form = new FormRegistroPedidoAdmin();
            form.Show();
        }
    }
}
